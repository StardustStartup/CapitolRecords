export const list = [
    {
        name: '1',
        path: require('..//assets/music/1.mp3'),
    },
    {
        name: '2',
        path: require('../assets/music/2.mp3'),
    },
    {
        name: '3',
        path: require('../assets/music/3.mp3'),
    },
    {
        name: '4',
        path: require('../assets/music/4.mp3'),
    },
    {
        name: '5',
        path: require('../assets/music/5.mp3'),
    },
    {
        name: '6',
        path: require('../assets/music/6.mp3'),
    }
];
