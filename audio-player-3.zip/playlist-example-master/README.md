# playlist example

An example app using the [Expo.Audio](https://docs.expo.io/versions/latest/sdk/audio/) & [Expo.Video](https://docs.expo.io/versions/latest/sdk/video/) API.

See [App.js](https://github.com/expo/playlist-example/blob/master/App.js) for the good stuff.

---

### Please report any issues at the [main Expo repository](https://github.com/expo/expo/issues)
