export default () => {
	return {
		duration: null,
		init: false,
		state: null,
		track: null,
		shuffle: false,
		replay: false,
		playing: false
	}
}
