export default () => {
	return {
		id: null,
		items: []
	}
}
