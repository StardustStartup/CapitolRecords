import React from 'react'
import Provider from './provider'

export default function App() {
	return <Provider />
}
