import reduxThunk from 'redux-thunk'

export default [reduxThunk]
