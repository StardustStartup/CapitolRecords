export default {
	layoutBG: 'rgb(52, 58, 64)',
	playerBG: 'rgb(35, 40, 44)',

	primary: 'rgb(225, 47, 129)',
	gray: 'rgb(131, 141, 149)',
	lightGray: 'rgb(241, 169, 207)',

	white: '#ddd'
}
