import { SERVICE_URL } from 'react-native-dotenv'

export default {
	SERVICE_URL
}
